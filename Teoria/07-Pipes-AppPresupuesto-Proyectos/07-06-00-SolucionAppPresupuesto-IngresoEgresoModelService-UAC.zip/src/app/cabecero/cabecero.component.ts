import { Component } from '@angular/core';

@Component({
  selector: 'app-cabecero',
  standalone: true,
  imports: [],
  templateUrl: './cabecero.component.html',
  styleUrl: './cabecero.component.css'
})
export class CabeceroComponent {

}
