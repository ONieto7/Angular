import { Component } from '@angular/core';

@Component({
  selector: 'app-ingreso',
  standalone: true,
  imports: [],
  templateUrl: './ingreso.component.html',
  styleUrl: './ingreso.component.css'
})
export class IngresoComponent {

}
