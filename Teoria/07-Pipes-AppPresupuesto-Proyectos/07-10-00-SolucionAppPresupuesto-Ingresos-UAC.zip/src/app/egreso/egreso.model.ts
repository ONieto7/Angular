export class Egreso{
    constructor(public descripcion: string, public valor:number){}
}