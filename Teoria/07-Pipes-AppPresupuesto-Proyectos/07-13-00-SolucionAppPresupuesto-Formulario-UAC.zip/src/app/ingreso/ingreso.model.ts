export class Ingreso{
    constructor(public descripcion: string, public valor:number){}
}