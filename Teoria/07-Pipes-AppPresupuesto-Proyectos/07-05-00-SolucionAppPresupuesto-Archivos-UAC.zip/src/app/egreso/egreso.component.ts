import { Component } from '@angular/core';

@Component({
  selector: 'app-egreso',
  standalone: true,
  imports: [],
  templateUrl: './egreso.component.html',
  styleUrl: './egreso.component.css'
})
export class EgresoComponent {

}
