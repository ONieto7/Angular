export class Producto{
    constructor(
        public descripcion: string,
        public precio: number
    ){}
}